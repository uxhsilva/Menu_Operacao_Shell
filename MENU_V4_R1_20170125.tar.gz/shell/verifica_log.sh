#
# Script : /export/ha/serpro/operacao/shell/verifica_log.sh
# OBS    : Script para Verificacao de Logs dos Sistemas em Producao
#          Como padrao em todas as maquinas a area de log dos jobs em
#          producao deve ser o diretorio : /xxx/xxx
#
# Feito  : Hertz S. em 11/09/2000
#
#
#--Declaracoes de Variaves-------------------------------[ CONFIGURAVEL ]-----
#
# Diretorio onde estao os Logs (Diretorios) dos Sistemas em Producao

# Acerto do Comando echo -----------------------------------------------------

   if [ "`uname -s`" = "Linux" ]
   then
      ECHO()
      {
      echo -e "$1"
      }
    else
      ECHO()
      {
      echo "$1"
      }
   fi

#-----------------------------------------------------------------------------


DIR_LOGS="${LOG_DIR_PROD}"

if [ -d $DIR_LOGS ]
then
  ECHO "Diretorio OK!" > /dev/null
else
  tput clear
  ECHO "\nDiretorio $DIR_LOGS NAO EXISTE !!"
  ECHO "\n\nTecle <RETURN> para continuar ...\c"
  read stop
  exit
fi

cd $DIR_LOGS

#-----------------------------------------------------------------------------
# Variaveis com os espacos em branco para posicionamento das opcoes do menu
# na tela
# OBS: NAO ALTERAR ESTAS VARIAVEIS
#

sp1=" "
sp2="  "
sp3="   "
sp4="    "
sp5="     "
sp6="      "
sp7="       "
sp8="        "
sp9="         "
sp10="          "
sp11="           "
sp12="            "
sp13="             "
sp14="              "
sp15="               "
sp16="                "
sp17="                 "
sp18="                  "
sp19="                   "
sp20="                    "
sp21="                     "
sp22="                      "
sp23="                       "
sp24="                        "
sp25="                         "
sp26="                          "
sp27="                           "
sp28="                            "
sp29="                             "
sp30="                              "
sp31="                               "
sp32="                                "
sp33="                                 "

#-----------------------------------------------------------------------------

cabecalho()
{
tput clear

ECHO "  `tput smso`                                                                             `tput rmso`"
ECHO "  `tput smso`             VERIFICACAO DE LOGS DA OPERACAO   -                             `tput rmso`"
ECHO "  `tput smso`                                                                             `tput rmso`"
ECHO "  Maquina : `hostname`"
NLOGS="`find ${DIR_LOGS} -type f | wc -l`"
NLOGS="`ECHO $NLOGS`"
CLOGS="`ECHO $NLOGS | wc -m`"
CLOGS="`ECHO $CLOGS`"
CLOGS="`expr $CLOGS - 1`"
COLUNA="`expr 74 - $CLOGS`"
tput cup 3 $COLUNA
ECHO "$NLOGS"
tput cup 3 75
ECHO "Logs"
tput cup 3 35
ECHO "`date +%d/%m/%Y`"
}

#-----------------------------------------------------------------------------

enviar_mail()
{
tput clear

ECHO "  `tput smso`                                                                             `tput rmso`"
ECHO "  `tput smso`             VERIFICACAO DE LOGS DA OPERACAO   -    G&P                      `tput rmso`"
ECHO "  `tput smso`                                                                             `tput rmso`"
ECHO "  Maquina : `hostname`"

mail_branco()
{
if [ "$mail" = "" ]
then
   inserir_mail
fi
}

inserir_mail()
{
   tput cup 10 10
   ECHO "Arquivo : `tput smso`  $file  `tput rmso`"
   tput cup 13 10
   ECHO "Mail : _______________________@${DOMINIO}"
   tput cup 13 17
   ECHO "\c"
   read mail
   mail_branco
}

inserir_mail

TMAIL="/tmp/tmpmail`date +%H%M%S%d%m%Y`"

ECHO "Subject: (`hostname`) $file - `date +%d/%m/%Y` as `date +%H:%M:%S`" > $TMAIL
tput cup 15 10
ECHO "From: root@`hostname`"

if [ "$t_file" = "ascii" ]
then
   cat $file >> $TMAIL
fi

if [ "$t_file" = "gzip" ]
then
   zcat $file >> $TMAIL
fi

tput cup 18 1
cat $TMAIL | /usr/sbin/sendmail $mail@${DOMINIO}
tput cup 18 1
ECHO "                                                                             "
rm $TMAIL 2>/dev/null

tput cup 22 25
ECHO "Tecle <RETURN> para continuar ...\c"
read stop
}

#-----------------------------------------------------------------------------

listar()
{

cabecalho

HORA=`date +%H%M%S`
DATA=`date +%d%m%Y`
DIA=`date +%d%m%Y`
var=0
VAR=0

if [ "$TIPO" = "dr" ]
then
   ls -lt | grep $TIPO | awk '{print $9}' | sort > /tmp/file.$HORA
else
   ls -lt | grep $TIPO | head -34 | awk '{print $9}' > /tmp/file.$HORA
fi

if [ -s /tmp/file.$HORA ]
then
   ECHO "existe" > /dev/null
else
   tput clear
   ECHO "\nNao ha LOGS para Analisar !\n"
   ECHO "Tecle <RETURN> para continuar ...\c"
   read stop
   exit
fi

cat /tmp/file.$HORA | while read x
do

seq=`expr $var + 1`
var=$seq
conf=`ECHO $x | cut -c1-29 | wc -c`
dif=`expr $TAMANHO - $conf`
VAR=`expr $VAR + 1`

if [ "$VAR" -lt 10 ]
then
   OPC=" $VAR"
else
   OPC="$VAR"
fi

ECHO "ECHO `ECHO \$`sp`ECHO $var`" > /tmp/arq.shh

ECHO "ESPACO=\"\$sp`ECHO $dif`\"" > /tmp/arq.$HORA
. /tmp/arq.$HORA

ECHO "  [`tput smso`$OPC`tput rmso`] - `ECHO $x| cut -c1-29`$ESPACO\c"

if [ "$seq" = $COLUNAS ]
then
   var=0
   seq=0
   ECHO ""
fi

ECHO "var$VAR=$x" >> /tmp/inc$HORA

done

. /tmp/inc$HORA

rm /tmp/inc$HORA
rm /tmp/arq.shh
rm /tmp/file.$HORA
rm /tmp/arq.$HORA

}

#-----------------------------------------------------------------------------

rodape_dir()
{

verificar()
{
tput cup 22 02
ECHO "`tput smso`[99 - Sair]`tput rmso` (`date +%d/%m/%Y` `date +%H:%M:%S`) - Qual SISTEMA ? : \c"
read sistema

if [ "$sistema" = 99 ]
then
   exit
fi

ECHO "sistema=\$var$sistema" > /tmp/inc$HORA

. /tmp/inc$HORA  2> /dev/null
rm /tmp/inc$HORA 2> /dev/null

if [ "$sistema" = "" ]
then
   tput cup 22 02
   ECHO "                                                                          \c "
   tput cup 22 02
   ECHO " Este sistema Nao esta cadastrado !!!! - Tecle <RETURN> para continuar ...\c"
   read stop
   tput cup 22 02
   ECHO "                                                                          \c "
   verificar
else
   ECHO "" > /dev/null
fi

if [ -d "$sistema" ]
then
   ECHO "" > /dev/null
else
   tput cup 22 02
   ECHO "                                                                          \c"
   tput cup 22 02
   ECHO " Este sistema Nao esta cadastrado !!!! - Tecle <RETURN> para continuar ...\c"
   read stop
   tput cup 22 02
   ECHO "                                                                          \c "
   verificar
fi

conta=`find $sistema -print | grep log | wc -l`
# conta=`find $DIR_LOGS/$sistema -print | grep log | wc -l`

if [ "$conta" -ge 1 ]
then
   ECHO "" > /dev/null
else
   tput cup 22 02
   ECHO "                                                                          \c"
   tput cup 22 02
   ECHO "Sistema sem conteudo !!! - Tecle <RETURN> para continuar ...\c"
   read stop
   tput cup 22 02
   ECHO "                                                                          \c"
   verificar
fi

}
verificar
}

#-----------------------------------------------------------------------------

rodape_file()
{
verificar_files()
{
Total=`find . -print | grep log | wc -l`
Total=`ECHO $Total`
tput cup 22 02
ECHO "`tput smso`[99 - Sair]`tput rmso` < `tput smso`$sistema`tput rmso` > ($Total) `date +%d/%m/%Y` `date +%H:%M:%S` > Log ? : \c"
read file

if [ "$file" = 99 ]
then
   exit
fi

ECHO "file=\$var$file" > /tmp/inc$HORA

. /tmp/inc$HORA
rm /tmp/inc$HORA

if [ -z "$file" ]
then
   tput cup 22 02
   ECHO "                                                                          \c"
   tput cup 22 02
   ECHO "  `tput smso` Este Log Nao Existe !!! `tput rmso` - Tecle <RETURN> para continuar ...\c"
   read stop
   tput cup 22 02
   ECHO "                                                                          \c"
   verificar_files
else
   ECHO "" > /dev/null
fi

if [ "$file" = "1" ]
then
   tput cup 22 02
   ECHO "                                                                          \c"
   tput cup 22 02
   ECHO "  `tput smso` Este Log Nao Existe !!! `tput rmso` - Tecle <RETURN> para continuar ...\c"
   read stop
   tput cup 22 02
   ECHO "                                                                          \c"
   verificar_files
else
   ECHO "" > /dev/null
fi

ARQUIVO_LOG="$file"
# ARQUIVO_LOG="$DIR_LOGS/$sistema/$file"

if [ -f "$ARQUIVO_LOG" ]
then
   ECHO "" > /dev/null
else
   tput cup 22 02
   ECHO "                                                                          \c"
   tput cup 22 02
   ECHO "  `tput smso` Este Log Nao Existe !!! `tput rmso` - Tecle <RETURN> para continuar ...\c"
   read stop
   tput cup 22 02
   ECHO "                                                                          \c"
   verificar_files
fi
}
verificar_files
}

#-----------------------------------------------------------------------------

DIR()
{
   COLUNAS=3
   TAMANHO=18
   TIPO=dr
   listar
   rodape_dir
}

#-----------------------------------------------------------------------------

DIR_DIR()
{
   COLUNAS=3
   TAMANHO=18
   TIPO=dr
   cd $sistema
   listar
   rodape_dir
}

#-----------------------------------------------------------------------------

DIR_FILE()
{
   cd $sistema

   COLUNAS=2
   TAMANHO=30
   TIPO=log
   listar
   rodape_file
}

#-----------------------------------------------------------------------------

menu()
{
   DIR
   DIR_DIR
   DIR_FILE
}

#-----------------------------------------------------------------------------

menu

tput clear

t_file="`file $file|cut -d\: -f2,2 | awk '{print $1}'`"
t_file="`ECHO $t_file`"

if [ "$t_file" = "ASCII" ]
then
   less $file
fi

if [ "$t_file" = "gzip" ]
then
   gunzip -c $file | less
fi

confirmar_mail()
{
tput clear
tput cup 22 0
ECHO "                                                                         "
tput cup 22 10
ECHO "Deseja Enviar Mail deste Log (S/N) : _\b\c"       
read confirmar

case $confirmar in

s|S) enviar_mail ;;
n|N) exit ;;
*) confirmar_mail ;;

esac
}

confirmar_mail
