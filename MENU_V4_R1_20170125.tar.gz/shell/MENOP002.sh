#
# Script: XXXXXXXX.sh ( Padrao : MENOP002.sh )
# Feito : Hertz S. (27/08/2000)
# Obs   : Os comentarios [ CONFIGURAVEL ] podem ser configurados
#         O Arquivo de Parametro para as opcoes e execucoes do Menu
#         estao no arquivo: ./XXXXXXXX.inc
#         Este menu contem : 23 opcoes com 27 caracteres cada opcao
#

tput clear

#-----------------------------------------------------------------------------
# Declaracoes de Variaves
# Obs: Nao alterar o conteudo destas variveis

 INCLUDE="`echo $0|cut -d. -f1,1`.inc"
. $INCLUDE
     CRC=$OPER_PATH/backup/$MENU.sh
     LOG=$OPER_PATH/MENU_OPERACAO.log
   Start=`tput smso`
    Stop=`tput rmso`
    HOST=`hostname|tr 'a-z' 'A-Z' | cut -d. -f1,1`
     TTY=`tty|cut -c6-`
    INFO="$OPER_PATH/txt/$MENU.txt"
LOG_HACK="$OPER_PATH/HACK.log"
  SYSTEM=`uname -s`

# Acerto do Comando echo -----------------------------------------------------

   if [ "`uname -s`" = "Linux" ]
   then
      ECHO()
      {
         echo -ne "$1"
      }
    else
      ECHO()
      {
         echo "$1"
      }
   fi

#-----------------------------------------------------------------------------

Informacao()
{

   if [ -f ${INFO} ]
   then
      tput clear
      less $INFO
   else
      tput clear
      ECHO "\nArquivo $INFO NAO EXISTE !!!"
      ECHO "\nChamar opcao \"info\" para criar arquivo de Informacao !"
   fi

}

#-----------------------------------------------------------------------------

edit_include()
{
   vi $INCLUDE
   ECHO "\n                          Tecle <RETURN> para continuar ...\c"
   read stop
   tput clear
}

#-----------------------------------------------------------------------------

edit_info()
{
   vi $INFO
   ECHO "\n                          Tecle <RETURN> para continuar ...\c"
   read stop
   tput clear
}

#-----------------------------------------------------------------------------

# Define metodo de HASH para senhas ------------------------------------------

type openssl 1>/dev/null 2>/dev/null
conf_openssl="$?"

if [ ${conf_openssl} -eq 0 ]
then
   echo existe openssl > /dev/null
   hash()
   {
   openssl dgst -sha1
   }
else
   type cksum 1>/dev/null 2>/dev/null
   conf_cksum="$?"

      if [ ${conf_cksum} -eq 0 ]
      then
         echo existe cksum > /dev/null
         hash()
         {
            cksum | sed 's: ::g'
         }
      else
         echo ""
         echo "Nao existe : CKSUM ou OPENSSL instalado no Sistema !"
         echo "Menu sera abortado ..."
         echo "Tecle <RETURN> ...\c"
         read stop
         exit 23
      fi

fi

#-----------------------------------------------------------------------------

senha_manutencao()
{
   senha()
   {
      tput cup 11 29
      ECHO "Senha         : \c"
      stty -echo
      read senha
      stty echo
      echo " "
      ct=`expr ${ct} + 1`

      if [ "${ct}" = 4 ]
      then
         echo "ADM;${IP};${TTY};${DATA};${HORA}" >> ${LOG_HACK}
         ECHO "\n\n                  ${Start}  Apos 3 Tentativas Processo Cancelado ...  ${Stop}\c"
         sleep 4
         opcoes
      fi

      conf_SENHA=`cat ${FILE_OPERATION} | grep ${ADMINISTRADOR} | cut -d: -f2,2`
      SENHA_SSL="`echo ${senha} | hash`"

      if [ ${conf_SENHA} = ${SENHA_SSL} ]
      then
         echo "" > /dev/null
      else
         ECHO "\n                                 ${Start}  Senha Invalida  ${Stop}"
         ECHO "\n\n                         Tecle <RETURN> para continuar ...\c"
         read stop
         tput cup 13 25
         echo "                                                   "
         tput cup 15 25
         echo "                                                   "
         senha
      fi

      ADM=`cat ${FILE_OPERATION} | grep $ADMINISTRADOR | cut -d: -f3,3`
   }

   ct=`expr ${ct} + 1`
   HORA

   if [ "${ct}" = 4 ]
   then
      echo "ADM;${IP};${TTY};${DATA};${HORA}" >> ${LOG_HACK}
      ECHO "\n\n                  ${Start}  Apos 3 Tentativas Processo Cancelado ...  ${Stop}\c"
      sleep 4
      opcoes
   fi

   tput clear

   echo " ${Start}                           ${Stop} ${Start}                                                 ${Stop}"
   echo " ${Start}${LOGO}${Stop} ${Start}    A U T E N T I C A C A O   S Y S   A D M      ${Stop}"
   echo " ${Start}                           ${Stop} ${Start}                                                 ${Stop}"

   ECHO "\n Hostname : ${Start}  `hostname`  ${Stop}"
   ECHO "\n\n\n\n\n\n                             Administrador : ______\b\b\b\b\b\b\c"
   read ADMINISTRADOR

   conf_ADMINISTRADOR="`echo ${ADMINISTRADOR} | wc -m`"

   if [ "${conf_ADMINISTRADOR}" -eq 1 ]
   then
      ECHO "\n\n                           ${Start}  Favor Identificar-se !!!  ${Stop}"
      ECHO "\n\n                         Tecle <RETURN> para continuar ...\c"
      read stop
      unset ADMINISTRADOR
      senha_manutencao
   else
      conf_ADMINISTRADOR=`cat ${FILE_OPERATION} | cut -d: -f1,1 | grep ${ADMINISTRADOR} | grep ADM | wc -l`
         if [ "${conf_ADMINISTRADOR}" -eq 0 ]
         then
            ECHO "\n\n                       ${Start}  Administrador $ADMINISTRADOR Nao Cadastrado !!! ${Stop}"
            ECHO "\n\n                         Tecle <RETURN> para continuar ...\c"
            read stop
            unset ADMINISTRADOR
            senha_manutencao
         else
            echo "" > /dev/null 
            ct=0
            senha
         fi
   fi
}

#-----------------------------------------------------------------------------

log()
{
     HR_FIM="`date +%H:%M:%S`"
     DT_FIM="`date +%d/%m/%Y`"

if [ "${opcao_escolhida}" = "" ]
then
   echo "" > /dev/null
else
   if [ "${sc_shell}" = "Warning_1" ]
   then
      echo "" > /dev/null
   else
      opcao_escolhida="`echo $opcao_escolhida`"
      echo "${OPER_FULL};${IP};${opcao_escolhida};$sc_shell;${DT_INI};${HR_INI};${DT_FIM};${HR_FIM};${MENU}" >> $LOG
   fi
fi
}

#-----------------------------------------------------------------------------

confirma()
{
HORA=`date +%H%M%S`
CONFIRMA="\$CONFIRMA_$OPCAO"
echo "CONFIRMA=$CONFIRMA" > arq.inc.$HORA
. ./arq.inc.$HORA
rm arq.inc.$HORA

if [ "$CONFIRMA" = S ]
then
tput clear

echo " $Start                           $Stop $Start                                                 $Stop"
echo " $Start${LOGO}$Stop $Start `date +%d/%m/%Y`                             `date +%H:%M:%S` $Stop" 
echo " $Start                           $Stop $Start                                                 $Stop"
ECHO "\n Hostname : $Start  $HOST  $Stop\n\n\n"
ECHO " $Start  $OPER  $Stop - Voce estara Executando:"
ECHO "\n\n\n       $Start  $opcao_escolhida  $Stop"
ECHO "\n\n\n Deseja Continuar (S/N) : _\b\c"
read conf_opcao

case $conf_opcao in

s|S) check_shell ;;
n|N) -ne echo "\n\n              Saindo ...   -   Tecle <RETURN> para continuar ...\c"
     read stop

     opcoes;;
*) ECHO "\n               $Start Opcao Invalida $Stop - Tecle <RETURN> para continuar ...\c"
   read stop
   opcoes;;
esac
fi

if [ "$CONFIRMA" = "N" ]
then
     check_shell
fi 
}

#-----------------------------------------------------------------------------

check_shell()
{
   if [ -f `echo $sc_shell | awk '{print $1}'` ]
   then      if [ -x `echo $sc_shell | awk '{print $1}'` ]
      then
         echo "" > /dev/null
      else
         chmod 755 `echo $sc_shell | awk '{print $1}'`
      fi
   else
      if [ "`echo $sc_shell | awk '{print $1}'`" = "Warning_1" ]
      then
         echo "" > /dev/null
      else
         if [ "`echo $sc_shell | awk '{print $1}'`" = "Informacao" ]
         then
              echo "" > /dev/null
          else
                 if [ "`echo $sc_shell | awk '{print $1}'`" = "edit_info" ]
                 then
                    echo "" > /dev/null
                 else
                    ECHO "\nScript : `echo $sc_shell | awk '{print $1}'` NAO EXISTE !"
                    ECHO "\n\n                         Tecle <RETURN> para continuar\
       ...\c"
                    read stop
                    opcoes   
           fi
         fi
      fi
   fi
}

#-----------------------------------------------------------------------------

parada()
{
   HORA=`date +%H%M%S`
   PARADA="\$PARADA_$OPCAO"
   echo "PARADA=$PARADA" > arq.inc.$HORA
   . ./arq.inc.$HORA
   rm arq.inc.$HORA

   if [ $PARADA = S ]
   then
      ECHO "\n\n                         Tecle <RETURN> para continuar ...\c"
      read stop
   fi

   if [ $PARADA = N ]
   then
      check_shell
   fi
}

#-----------------------------------------------------------------------------

check_sys_menu()
{

if [ -f $CRC ]
then
   echo "" > /dev/null
else
   ECHO "\n  Arquivo de Backup do Menu: $CRC "
   ECHO "\n  NAO Existe !!"
   ECHO "\n  $Start                   Contate o Administrador do Sistema !!                   $Stop"
   parada
   exit
fi

CK_SUM_FILE1=`cksum $CRC | awk '{print $1}'`
CK_SUM_FILE2=`cksum $OPER_PATH/$MENU.sh | awk '{print $1}'`

if [ $CK_SUM_FILE1 = $CK_SUM_FILE2 ]
then
   echo "" > /dev/null
else
   ECHO "\n  Script: $MENU.sh Foi alterado do Original !! "
   ECHO "\n\n  $Start                   Contate o Administrador do Sistema !!                   $Stop"
   ECHO "\n\n  Tecle <RETURN> para continuar ...\c"
   read stop
   exit
fi

}

#-----------------------------------------------------------------------------

# Tela do Menu

opcoes()
{
IPJ="`echo ${IP} | cut -c1-10`"
ctaopr=`echo $OPER|wc -m`
POS=`expr $ctaopr + 25`
. $INCLUDE

tput clear

cat << EOF
  $Start $HOST $Stop IP: $Start $IPJ $Stop Dev:$Start $TTY $Stop Data:$Start `date +%D` $Stop Hora:$Start `date +%H:%M:%S` $Stop
+---------------+-------------------------------------------------------------+
| $Start             $Stop | $Start                                                           $Stop |
| $Start${LOGO_2}$Stop | $Start $MENU_NAME $Stop |
| $Start             $Stop | $Start                                                           $Stop |
+---------------+-------------------------------------------------------------+
| $DSP_A $OPCAO_A  $DSP_N $OPCAO_N  |
| $DSP_B $OPCAO_B  $DSP_O $OPCAO_O  |
| $DSP_C $OPCAO_C  $DSP_P $OPCAO_P  |
| $DSP_D $OPCAO_D  $DSP_Q $OPCAO_Q  |
| $DSP_E $OPCAO_E  $DSP_R $OPCAO_R  |
| $DSP_F $OPCAO_F  $DSP_S $OPCAO_S  |
| $DSP_G $OPCAO_G  $DSP_T $OPCAO_S  |
| $DSP_H $OPCAO_H  $DSP_U $OPCAO_U  |
| $DSP_J $OPCAO_J  $DSP_V $OPCAO_V  |
| $DSP_K $OPCAO_K  $DSP_W $OPCAO_W  |
| $DSP_L $OPCAO_L  $DSP_Y $OPCAO_Y  |
| $DSP_M $OPCAO_M  $DSP_I $OPCAO_I  |
|                                                                             |
| [$Start X $Stop] - $OPCAO_X  [$Start PP $Stop] - $OPCAO_PP |
|                                                                             |
+-----------------------------------------------------------------------------+
EOF

conferencia()
{
tput cup 22 0
ECHO " $Start  $OPER  $Stop Entre com a Opcao : _\c"
tput cup 22 65
ECHO "$Start $MENU.sh $Stop\c"
tput cup 22 $POS
read opcao
tput cup 22 $POS
ECHO "   Aguarde ...\c"

OPCAO="`echo $opcao | tr 'a-z' 'A-Z'`"

case $opcao in

#------------------------------------------------------------------------------

edit|EDIT) opcao_escolhida="Edicao do Include : $INCLUDE"
     HR_INI="`date +%H:%M:%S`"
     DT_INI="`date +%d/%m/%Y`"
     ct=0
     sc_shell="F_edit"
     senha_manutencao
     edit_include
     HR_FIM="`date +%H:%M:%S`"
     DT_FIM="`date +%d/%m/%Y`"
     log
     opcao_escolhida=""
     unset sc_shell
     opcoes;;

#-----------------------------------------------------------------------------

info|INFO) opcao_escolhida="Edicao de Informacoes do Menu : $INCLUDE"
     HR_INI="`date +%H:%M:%S`"
     DT_INI="`date +%d/%m/%Y`"
     ct=0
     sc_shell="F_info"
     senha_manutencao
     edit_info
     HR_FIM="`date +%H:%M:%S`"
     DT_FIM="`date +%d/%m/%Y`"
     log
     unset sc_shell
     opcoes;;

#-----------------------------------------------------------------------------

a|A) opcao_escolhida=$OPCAO_A
     HR_INI="`date +%H:%M:%S`"
     DT_INI="`date +%d/%m/%Y`"
     sc_shell="$Exec_OPCAO_A"
     confirma
     $Exec_OPCAO_A
     if [ "${Exec_OPCAO_A}" = "Warning_1" ]
     then 
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_A=""
     opcoes ;;

#------------------------------------------------------------------------------

b|B) opcao_escolhida=$OPCAO_B
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_B"
     confirma
     $Exec_OPCAO_B
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_B}" = "Warning_1" ]
     then 
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_B=""
     opcoes ;;

#------------------------------------------------------------------------------

c|C) opcao_escolhida=$OPCAO_C
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_C"
     confirma
     $Exec_OPCAO_C
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_C}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_C=""
     opcoes ;;

#------------------------------------------------------------------------------

d|D) opcao_escolhida=$OPCAO_D
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_D"
     confirma
     $Exec_OPCAO_D
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_D}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_D=""
     opcoes ;;

#------------------------------------------------------------------------------

e|E) opcao_escolhida=$OPCAO_E
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_E"
     confirma
     $Exec_OPCAO_E
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_E}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_E=""
     opcoes ;;

#------------------------------------------------------------------------------

f|F) opcao_escolhida=$OPCAO_F
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_F"
     confirma
     $Exec_OPCAO_F
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_F}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_F=""
     opcoes ;;

#------------------------------------------------------------------------------

g|G) opcao_escolhida=$OPCAO_G
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_G"
     confirma
     $Exec_OPCAO_G
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_G}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_G=""
     opcoes ;;

#------------------------------------------------------------------------------

h|H) opcao_escolhida=$OPCAO_H
     sc_shell="$Exec_OPCAO_H"
     confirma
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     $Exec_OPCAO_H
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_H}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_H=""
     opcoes ;;

#------------------------------------------------------------------------------

i|I) opcao_escolhida=$OPCAO_I
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     $Exec_OPCAO_I
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_I}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_I=""
     opcoes ;;

#------------------------------------------------------------------------------

j|J) opcao_escolhida=$OPCAO_J
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_J"
     confirma
     $Exec_OPCAO_J
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_J}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_J=""
     opcoes ;;

#------------------------------------------------------------------------------

k|K) opcao_escolhida=$OPCAO_K
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_K"
     confirma
     $Exec_OPCAO_K
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_K}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_K=""
     opcoes ;;

#------------------------------------------------------------------------------

l|L) opcao_escolhida=$OPCAO_L
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_L"
     confirma
     $Exec_OPCAO_L
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_L}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_L=""
     opcoes ;;

#------------------------------------------------------------------------------

m|M) opcao_escolhida=$OPCAO_M
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_M"
     confirma
     $Exec_OPCAO_M
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_M}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_M=""
     opcoes ;;

#------------------------------------------------------------------------------

n|N) opcao_escolhida=$OPCAO_N
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_N"
     confirma
     $Exec_OPCAO_N
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_N}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_N=""
     opcoes ;;

#------------------------------------------------------------------------------

o|O) opcao_escolhida=$OPCAO_O
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_O"
     confirma
     $Exec_OPCAO_O
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_O}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_O=""
     opcoes ;;

#------------------------------------------------------------------------------

p|P) opcao_escolhida=$OPCAO_P
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_P"
     confirma
     $Exec_OPCAO_P
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_P}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_P=""
     opcoes ;;

#------------------------------------------------------------------------------

q|Q) opcao_escolhida=$OPCAO_Q
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_Q"
     confirma
     $Exec_OPCAO_Q
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_Q}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_Q=""
     opcoes ;;

#------------------------------------------------------------------------------

r|R) opcao_escolhida=$OPCAO_R
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_R"
     confirma
     $Exec_OPCAO_R
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_R}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_R=""
     opcoes ;;

#------------------------------------------------------------------------------

s|S) opcao_escolhida=$OPCAO_S
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_S"
     confirma
     $Exec_OPCAO_S
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_S}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_S=""
     opcoes ;;

#------------------------------------------------------------------------------

t|T) opcao_escolhida=$OPCAO_T
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_T"
     confirma
     $Exec_OPCAO_T
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_T}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_T="" 
     opcoes ;;

#------------------------------------------------------------------------------

u|U) opcao_escolhida=$OPCAO_U
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_U"
     confirma
     $Exec_OPCAO_U
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_U}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_U=""
     opcoes ;;

#------------------------------------------------------------------------------

v|V) opcao_escolhida=$OPCAO_V
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_V"
     confirma
     $Exec_OPCAO_V
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_V}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_V=""
     opcoes ;;

#------------------------------------------------------------------------------

w|W) opcao_escolhida=$OPCAO_W
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_W"
     confirma
     $Exec_OPCAO_W
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_W}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_W=""
     opcoes ;;

#------------------------------------------------------------------------------

y|Y) opcao_escolhida=$OPCAO_Y
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_Y"
     confirma
     $Exec_OPCAO_Y
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_H}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_Y=""
     opcoes ;;

#------------------------------------------------------------------------------

pp|PP) opcao_escolhida=$OPCAO_PP
     HR_INI=`date +%H:%M:%S`
     DT_INI=`date +%D`
     sc_shell="$Exec_OPCAO_PP"
     confirma
     $Exec_OPCAO_PP
     HR_FIM=`date +%H:%M:%S`
     DT_FIM=`date +%D`
     if [ "${Exec_OPCAO_PP}" = "Warning_1" ]
     then
        echo . > /dev/null
     else
        log
     fi
     parada
     opcao_escolhida=""
     Exec_OPCAO_PP=""
     opcoes ;;

#------------------------------------------------------------------------------

x|X) Exec_OPCAO_A="" ; Exec_OPCAO_B="" ; Exec_OPCAO_C=""
     Exec_OPCAO_D="" ; Exec_OPCAO_E="" ; Exec_OPCAO_F=""
     Exec_OPCAO_G="" ; Exec_OPCAO_H=""  
     Exec_OPCAO_J="" ; Exec_OPCAO_K="" ; Exec_OPCAO_L=""
     Exec_OPCAO_M="" ; Exec_OPCAO_N="" ; Exec_OPCAO_O=""
     Exec_OPCAO_P="" ; Exec_OPCAO_Q="" ; Exec_OPCAO_R=""
     Exec_OPCAO_S="" ; Exec_OPCAO_T="" ; Exec_OPCAO_U=""
     Exec_OPCAO_V="" ; Exec_OPCAO_W="" ; Exec_OPCAO_X=""
     Exec_OPCAO_Y="" ; Exec_OPCAO_Z="" ; Exec_OPCAO_PP=""
     opcao_escolhida=""
     exit 0 ;;

z|Z) opcao_escolhida=$OPCAO_Z
     Exec_OPCAO_A="" ; Exec_OPCAO_B="" ; Exec_OPCAO_C=""
     Exec_OPCAO_D="" ; Exec_OPCAO_E="" ; Exec_OPCAO_F=""
     Exec_OPCAO_G="" ; Exec_OPCAO_H="" 
     Exec_OPCAO_J="" ; Exec_OPCAO_K="" ; Exec_OPCAO_L=""
     Exec_OPCAO_M="" ; Exec_OPCAO_N="" ; Exec_OPCAO_O=""
     Exec_OPCAO_P="" ; Exec_OPCAO_Q="" ; Exec_OPCAO_R=""
     Exec_OPCAO_S="" ; Exec_OPCAO_T="" ; Exec_OPCAO_U=""
     Exec_OPCAO_V="" ; Exec_OPCAO_W="" ; Exec_OPCAO_X=""
     Exec_OPCAO_Y="" ; Exec_OPCAO_Z="" ; Exec_OPCAO_PP=""
     log
     tput clear
     exit ;;

*) tput cup 22 0
   ECHO "                                                                                 \c" 
   tput cup 22 0
   ECHO "               $Start Opcao Invalida $Stop - Tecle <RETURN> para continuar ...\c"
   read stop
   tput cup 22 0
   ECHO "                                                                               "
   conferencia ;;

esac
}

conferencia

}

#-----------------------------------------------------------------------------

DATA=`date +%d/%m/%Y`
HORA=`date +%H:%M:%S`
ct=0

check_sys_menu
opcoes
