#
mkdir -p ~operacao/avisos

    DOMINIO="DOMINIOEMPRESA" # Informar Dominio de Rede da Empresa

#
# Script: aviso.sh
#

tput clear
HORA=`date +%d%m%y_%H%M%S`

# Acerto do Comando echo -----------------------------------------------------

   if [ "`uname -s`" = "Linux" ]
   then
      ECHO()
      {
      echo -e "$1"
      }
    else
      ECHO()
      {
      echo "$1"
      }
   fi

#------------------------------------------------------------------------------

cabecalho()
{
tput clear
cat << EOT

+============================================================================+
| `tput smso`                     `tput rmso` `tput smso`                                                    `tput rmso` |
| `tput smso`                     `tput rmso` `tput smso`           S I S T E M A   D E   A V I S O S        `tput rmso` |
| `tput smso`                     `tput rmso` `tput smso`                                                    `tput rmso` |
+============================================================================+

EOT
tput cup 0 1
echo "`tput smso``date +%d/%m/%y``tput rmso`"
tput cup 0 35 
echo "`tput smso``hostname``tput rmso`"
tput cup 0 69
echo "`tput smso``date +%H:%M:%S``tput rmso`"
tput cup 8
}

#-----------------------------------------------------------------------------

cabecalho
echo "   Mail do qual deseja avisar: __________________________@${DOMINIO}"
ECHO "\n   Subject do Mail:"
echo "   ________________________________________________________________________"
echo "   ________________________________________________________________________"
echo "   ________________________________________________________________________"
echo "   ________________________________________________________________________"
ECHO "\n   Dia: `date +%d`"
echo "   Mes: `date +%m`   Ano: `date +%Y`"
echo "   Hora (hh:mm) : `date +%H:%M`"

tput cup 8 31
echo "____________"

tput cup 8 31
read mail

if [ "$mail" = "" ] ; then mail="operacao" ; fi

tput cup 10 20
read subject

tput cup 11 3
read linha1

tput cup 12 3
read linha2

tput cup 13 3
read linha3

tput cup 14 3
read linha4

tput cup 16 8
read dia

if [ "$dia" = "" ] ; then dia="`date +%d`" ; fi

tput cup 17 8
read mes

if [ "$mes" = "" ] ; then mes="`date +%m`" ; fi

tput cup 17 18
read ano 

if [ "$ano" = "" ] ; then ano="`date +%Y`" ; fi

tput cup 18 18
echo "`date +%H:%M`"
tput cup 18 18
read hora

HR="`date +%H:%M`"
if [ "$hora" = "" ] ; then hora="$HR" ; fi

cabecalho

echo "   Mail do qual deseja avisar: $mail@tokstok.com.br"
ECHO "\n   Subject do Mail: $subject"
ECHO "\n   $linha1"
echo "   $linha2"
echo "   $linha3"
echo "   $linha4"
ECHO "\n                 A Mensagem Sera Entregue : $dia/$mes/$ano as $hora"

confirmacao()
{
tput cup 20 22
ECHO "Confirma (S/N): \c"
read conf
tput cup 20 22
echo "                                                                      "

case $conf in

s|S) echo "                                                                   "
     echo "" > /dev/null;;
n|N) tput clear
     exit;;
*) tput cup 20 22
   ECHO "Opcao Invalida - Tecle <RETURN> para continuar ...\c"
   read stop
   tput cup 20 22
   echo "                                                                    "
   confirmacao;;

esac
}

confirmacao

#----------------------------------------------------------------------------

echo "Subject: $subject" > ~operacao/avisos/arq.tmp.$HORA
echo "From: Avisos para Operacao" >> ~operacao/avisos/arq.tmp.$HORA
echo "$linha1" >> ~operacao/avisos/arq.tmp.$HORA
echo "$linha2" >> ~operacao/avisos/arq.tmp.$HORA
echo "$linha3" >> ~operacao/avisos/arq.tmp.$HORA
echo "$linha4" >> ~operacao/avisos/arq.tmp.$HORA

if [ "$mes" = 01 ] ; then mes=Jan ; fi
if [ "$mes" = 1 ] ; then mes=Jan ; fi
if [ "$mes" = 02 ] ; then mes=Feb ; fi
if [ "$mes" = 2 ] ; then mes=Feb ; fi
if [ "$mes" = 03 ] ; then mes=Mar ; fi
if [ "$mes" = 3 ] ; then mes=Mar ; fi
if [ "$mes" = 04 ] ; then mes=Apr ; fi
if [ "$mes" = 4 ] ; then mes=Apr ; fi
if [ "$mes" = 05 ] ; then mes=May ; fi
if [ "$mes" = 5 ] ; then mes=May ; fi
if [ "$mes" = 06 ] ; then mes=Jun ; fi
if [ "$mes" = 6 ] ; then mes=Jun ; fi
if [ "$mes" = 07 ] ; then mes=Jul ; fi
if [ "$mes" = 7 ] ; then mes=Jul ; fi
if [ "$mes" = 08 ] ; then mes=Aug ; fi
if [ "$mes" = 8 ] ; then mes=Aug ; fi
if [ "$mes" = 09 ] ; then mes=Sep ; fi
if [ "$mes" = 9 ] ; then mes=Sep ; fi
if [ "$mes" = 10 ] ; then mes=Oct ; fi
if [ "$mes" = 11 ] ; then mes=Nov ; fi
if [ "$mes" = 12 ] ; then mes=Dec ; fi

echo "/usr/lib/sendmail $mail@tokstok.com.br < ~operacao/avisos/arq.tmp.$HORA" > ~operacao/avisos/mail.arq.$HORA
echo "rm ~operacao/avisos/arq.tmp.$HORA" >> ~operacao/avisos/mail.arq.$HORA
echo "rm ~operacao/avisos/mail.arq.$HORA" >> ~operacao/avisos/mail.arq.$HORA

/usr/bin/at $hora $mes $dia < ~operacao/avisos/mail.arq.$HORA 2> /dev/null

if [ $? != 0 ]
then
   echo ""
   tput cup 20 10
   echo "`tput smso`Houve erro em alguma Informacao - ENVIAR NOVAMENTE`tput rmso`"
else
   tput cup 20 10
   echo "Mail enviado com Sucesso para: `tput smso`$mail@tokstok.com.br`tput rmso`"
fi

tput cup 22 25
ECHO "Tecle <RETURN> para continuar ...\c"
read stop
