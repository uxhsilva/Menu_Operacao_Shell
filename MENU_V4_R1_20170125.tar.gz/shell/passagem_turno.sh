#
# Script: passagem_turno.sh
# Feito : Hertz S.
# Data  : 13/09/2000
#

             DIA=`date +%d%m%Y`
             MES=`date +%m_%Y`
    DIR_PASSAGEM="$OPER_PATH/turno"
DIR_PASSAGEM_MES="$DIR_PASSAGEM/$MES"
   PASSAGEM_FILE="$DIR_PASSAGEM/$MES/$DIA.txt"
            HOST=`hostname|tr 'a-z' 'A-Z' | cut -d. -f1,1`
             TTY=`tty|cut -c6-`
           Start=`tput smso`
            Stop=`tput rmso`
       MENU_NAME="           P A S S A G E M   D E   T U R N O             "
        OPERADOR=$OPER_FULL
            MENU="passagem_turno"
       OPER_PATH=/home/operacao/shell
             CRC=$OPER_PATH/backup/$MENU.sh
      FILE_EVENT="/home/operacao/shell/avisos.txt"

# Acerto do Comando echo -----------------------------------------------------

   if [ "`uname -s`" = "Linux" ]
   then
      ECHO()
      {
      echo -ne "$1"
      }
    else
      ECHO()
      {
      echo "$1"
      }
   fi

#-----------------------------------------------------------------------------

if [ -z "${OPER_FULL}" ]
then
   ECHO "\nEste script deve ser executado de dentro do MENOP001.sh !\n"
   ECHO "\nTecle <RETURN> ...\c"
   read stop
   exit 23
fi

if [ -z ${OPER_PATH} ]
then
   ECHO "\nVariavel OPER_PATH deve ser inicializada \n"
   ECHO "\nTecle <RETURN> ...\c"
   read stop
   exit 23
else
   mkdir -p $DIR_PASSAGEM_MES 2> /dev/null
fi

#-----------------------------------------------------------------------------

if [ "$TTY" = tty0 ]
then
   TTY=console
fi

cd $OPER_PATH

#-----------------------------------------------------------------------------

cabecalho()
{
tput clear

echo "  `tput smso`                                                                             `tput rmso`"
echo "  `tput smso`      P A S S A G E M   D E   T U R N O  -  $LOGO      `tput rmso`"
ECHO "  `tput smso`                                                                             `tput rmso`\n"
}

cabecalho_1()
{
tput clear

echo "  `tput smso`                                                                             `tput rmso`"
echo "  `tput smso`        E V E N T O S   O P E R A C A O   -  $LOGO     `tput rmso`"
ECHO "  `tput smso`                                                                             `tput rmso`\n"
}
#-----------------------------------------------------------------------------

conf_linha()
{
l=$l
conta_l1=`echo $l | wc -m`

if [ $conta_l1 -gt 66 ]
then
tput cup 19 1
echo "  Cada Linha Permite 66 Caracteres - Por Favor Digitar novamente !!"
parada
tput cup 19 1
echo "                                                                                 "
tput cup 22 1
echo "                                                                         "
tput cup $linha $coluna
echo "        _________________________________________________________________       "
tput cup $linha $coluna
$rotina
fi
}

#-----------------------------------------------------------------------------

inserir_dados()
{

cabecalho

ECHO "\n  Operador : $Start  $OPERADOR  $Stop ( $HORA ) - $DT_ATUAL\n\n" 

echo "        _________________________________________________________________"
echo "        _________________________________________________________________"
echo "        _________________________________________________________________"
echo "        _________________________________________________________________"
echo "        _________________________________________________________________"
echo "        _________________________________________________________________"
echo "        _________________________________________________________________"
echo "        _________________________________________________________________"
echo "        _________________________________________________________________"
echo "        _________________________________________________________________"

linha1()
{
tput cup 6 0
echo "        _________________________________________________________________"
tput cup 6 8
read linha1
l=$linha1
rotina=linha1
linha=6
coluna=0
conf_linha
}

linha2()
{
tput cup 7 0
echo "        _________________________________________________________________"
tput cup 7 8
read linha2
l=$linha2
rotina=linha2
linha=7
coluna=0
conf_linha
}

linha3()
{
tput cup 8 0
echo "        _________________________________________________________________"
tput cup 8 8
read linha3
l=$linha3
rotina=linha3
linha=8
coluna=0
conf_linha
}

linha4()
{
tput cup 9 0
echo "        _________________________________________________________________"
tput cup 9 8
read linha4
l=$linha4
rotina=linha4
linha=9
coluna=0
conf_linha
}

linha5()
{
tput cup 10 0
echo "        _________________________________________________________________"
tput cup 10 8
read linha5
l=$linha5
rotina=linha5
linha=10
coluna=0
conf_linha
}

linha6()
{
tput cup 11 0
echo "        _________________________________________________________________"
tput cup 11 8
read linha6
l=$linha6
rotina=linha6
linha=11
coluna=0
conf_linha
}

linha7()
{
tput cup 12 0
echo "        _________________________________________________________________"
tput cup 12 8
read linha7
l=$linha7
rotina=linha7
linha=12
coluna=0
conf_linha
}

linha8()
{
tput cup 13 0
echo "        _________________________________________________________________"
tput cup 13 8
read linha8
l=$linha8
rotina=linha8
linha=13
coluna=0
conf_linha
}

linha9()
{
tput cup 14 0
echo "        _________________________________________________________________"
tput cup 14 8
read linha9
l=$linha9
rotina=linha9
linha=14
coluna=0
conf_linha
}

linha10()
{
tput cup 15 0
echo "        _________________________________________________________________"
tput cup 15 8
read linha10
l=$linha10
rotina=linha10
linha=15
coluna=0
conf_linha
}

linha1
linha2
linha3
linha4
linha5
linha6
linha7
linha8
linha9
linha10

tput cup 6 0 ; echo "                                                                                 "
tput cup 7 0 ; echo "                                                                                 "
tput cup 8 0 ; echo "                                                                                 "
tput cup 9 0 ; echo "                                                                                 "
tput cup 10 0 ; echo "                                                                                 "
tput cup 11 0 ; echo "                                                                                 "
tput cup 12 0 ; echo "                                                                                 "
tput cup 13 0 ; echo "                                                                                 "
tput cup 14 0 ; echo "                                                                                 "
tput cup 15 0 ; echo "                                                                                 "
tput cup 6 0

echo "        $linha1"
echo "        $linha2"
echo "        $linha3"
echo "        $linha4"
echo "        $linha5"
echo "        $linha6"
echo "        $linha7"
echo "        $linha8"
echo "        $linha9"
echo "        $linha10"

confirma()
{
tput cup 17 0
ECHO "                         Estao Corretos os Dados (S/N) : _\b\c"
read conf

case $conf in

s|S) ECHO "\nOperador : $OPERADOR ( $HORA )\n\n" >> $PASSAGEM_FILE

     if [ -z "$linha1" ]
     then
     echo "" > /dev/null
     else
     echo "  $linha1" >> $PASSAGEM_FILE
     fi

     if [ -z "$linha2" ]
     then
     echo "" > /dev/null
     else
     echo "  $linha2" >> $PASSAGEM_FILE
     fi

     if [ -z "$linha3" ]
     then
     echo "" > /dev/null
     else
     echo "  $linha3" >> $PASSAGEM_FILE
     fi

     if [ -z "$linha4" ]
     then
     echo "" > /dev/null
     else
     echo "  $linha4" >> $PASSAGEM_FILE
     fi

     if [ -z "$linha5" ]
     then
     echo "" >> $PASSAGEM_FILE
     echo "" > /dev/null
     else
     echo "  $linha5" >> $PASSAGEM_FILE
     fi
    
     if [ -z "$linha6" ]
     then
     echo "" > /dev/null
     else
     echo "  $linha6" >> $PASSAGEM_FILE
     fi

     if [ -z "$linha7" ]
     then
     echo "" > /dev/null
     else
     echo "  $linha7" >> $PASSAGEM_FILE
     fi

     if [ -z "$linha8" ]
     then
     echo "" > /dev/null
     else
     echo "  $linha8" >> $PASSAGEM_FILE
     fi

     if [ -z "$linha9" ]
     then
     echo "" > /dev/null
     else
     echo "  $linha9" >> $PASSAGEM_FILE
     fi

     if [ -z "$linha10" ] 
     then
     echo "" >> $PASSAGEM_FILE
     else
     ECHO "  $linha10\n\n" >> $PASSAGEM_FILE
     fi
     
     echo "" > /dev/null ;;

n|N) echo "" > /dev/null ;;

*) tput cup 14 0
   ECHO "                  Opcao Invalida - Tecle <RETURN> para continuar ...\c"
   read stop
   tput cup 14 0
   echo "                                                                      "
   tput cup 12 0
   echo "                                                                               "
   confirma ;;

esac

}

confirma

}

#-----------------------------------------------------------------------------

parada()
{
ECHO "\n\n                         Tecle <RETURN> para continuar ...\c"
read stop
}

#-----------------------------------------------------------------------------

uso()
{
if [ -f $PASSAGEM_FILE.uso ]
then
tput clear
tty=`cat $PASSAGEM_FILE.uso|awk '{print $2}'`
cpo=`cat $PASSAGEM_FILE.uso|awk '{print $1}'`
echo "            Este Arquivo Ja Esta em Uso no Terminal $Start $tty $Stop"
ECHO "            Pelo Operador : $Start  $cpo  $Stop\n\n"
ECHO "            Voce NAO pode Usar o Arquivo com outro Usuario Utilizando!\n\n"
parada
opcoes
else
echo "$OPERADOR `tty`" > $PASSAGEM_FILE.uso
echo "" > /dev/null
fi
}

#-----------------------------------------------------------------------------

passagem()
{
HORA=`date +%H:%M:%S`
if [ -f $PASSAGEM_FILE ]
then
uso
inserir_dados
else
uso
ECHO "[ $LOGO ] - PASSAGEM DE TURNO : `date +%d/%m/%Y`\n" >> $PASSAGEM_FILE
inserir_dados
fi
}

#-----------------------------------------------------------------------------

passagem_dia()
{

cd $DIR_PASSAGEM

sistema=""
file=""

DIR_LOGS="$DIR_PASSAGEM"

#--------------------------------------

cd $DIR_LOGS

sp1=" "
sp2="  "
sp3="   "
sp4="    "
sp5="     "
sp6="      "
sp7="       "
sp8="        "
sp9="         "
sp10="          "
sp11="           "
sp12="            "
sp13="             "
sp14="              "
sp15="               "
sp16="                "
sp17="                 "
sp18="                  "
sp19="                   "
sp20="                    "
sp21="                     "
sp22="                      "
sp23="                       "
sp24="                        "
sp25="                         "
sp26="                          "
sp27="                           "
sp28="                            "
sp29="                             "
sp30="                              "
sp31="                               "
sp32="                                "
sp33="                                 "

#--------------------------------------

listar()
{

cabecalho

HORA=`date +%H%M%S`
DATA=`date +%d%m%Y`
DIA=`date +%d%m%Y`
var=0
VAR=0

if [ TIPO = "dr" ]
then
ls -lt | grep $TIPO | grep -v uso | awk '{print $9}' | sort > /tmp/file.$HORA
else
ls -lt | grep $TIPO | grep -v uso |  tail -34 | awk '{print $9}' | sort > /tmp/file.$HORA
fi

cat /tmp/file.$HORA | while read x
do

seq=`expr $var + 1`
var=$seq
conf=`echo $x | wc -c`
dif=`expr $TAMANHO - $conf`
VAR=`expr $VAR + 1`

if [ $VAR -lt 10 ]
then
OPC=" $VAR"
else
OPC="$VAR"
fi

echo "echo `echo \$`sp`echo $var`" > /tmp/arq.shh

echo "ESPACO=\"\$sp`echo $dif`\"" > /tmp/arq.$HORA
. /tmp/arq.$HORA

if [ $TIPO = "dr" ]
then
mes=`echo $x | cut -c1-2`
ano=`echo $x | cut -c4-7`
if [ "$mes" = 01 ] ; then MES="Jan" ; fi
if [ "$mes" = 02 ] ; then MES="Fev" ; fi
if [ "$mes" = 03 ] ; then MES="Mar" ; fi
if [ "$mes" = 04 ] ; then MES="Abr" ; fi
if [ "$mes" = 05 ] ; then MES="Mai" ; fi
if [ "$mes" = 06 ] ; then MES="Jun" ; fi
if [ "$mes" = 07 ] ; then MES="Jul" ; fi
if [ "$mes" = 08 ] ; then MES="Ago" ; fi
if [ "$mes" = 09 ] ; then MES="Set" ; fi
if [ "$mes" = 10 ] ; then MES="Out" ; fi
if [ "$mes" = 11 ] ; then MES="Nov" ; fi
if [ "$mes" = 12 ] ; then MES="Dez" ; fi
X="$MES $ano"
ECHO "   [`tput smso`$OPC`tput rmso`] - $X$ESPACO \c"
else
dia=`echo $x | cut -c1-2`
mes=`echo $x | cut -c3-4`
ano=`echo $x | cut -c5-8`
X="$dia/$mes/$ano"
ECHO "   [`tput smso`$OPC`tput rmso`] - $X$ESPACO \c"
fi

if [ $seq = $COLUNAS ]
then
var=0
seq=0
echo ""
fi

echo "var$VAR=$x" >> /tmp/inc$HORA

done

ECHO "\n\n\n   [$Start 99 $Stop] - Sair\n"

. /tmp/inc$HORA

rm /tmp/inc$HORA
rm /tmp/arq.shh
rm /tmp/file.$HORA
rm /tmp/arq.$HORA

}

#--------------------------------------

rodape_dir()
{

tput cup 15 3
ECHO "[ $OPER ] - Qual MES deseja Verificar ? : \c"
read sistema

if [ "$sistema" = "" ]
then
ECHO "\n               [`tput smso` $OPER `tput rmso`] Variavel MES Incorreta !!!  `tput rmso`"
ECHO "\n                         Tecle <RETURN> para continuar ...\c"
read stop
tput cup 17 3
echo "                                                                              "
tput cup 19 3
echo "                                                                              "
rodape_dir
else
echo "" > /dev/null
fi

if [ $sistema = 99 ]
then
opcoes
fi

echo "sistema=\$var$sistema" > /tmp/inc$HORA

. /tmp/inc$HORA  2> /dev/null
rm /tmp/inc$HORA 2> /dev/null

if [ "$sistema" = "" ]
then
ECHO "\n               [`tput smso` $OPER `tput rmso`] Variavel MES Incorreta !!!  `tput rmso`"
ECHO "\n                         Tecle <RETURN> para continuar ...\c"
read stop
tput cup 17 3
echo "                                                                              "
tput cup 19 3
echo "                                                                              "
rodape_dir
else
echo "" > /dev/null
fi

if [ -d "$sistema" ]
then
echo "" > /dev/null
else
ECHO "\n               [`tput smso` $OPER `tput rmso`] Variavel MES Incorreta !!!  `tput rmso`"
read stop
tput cup 17 3
echo "                                                                              "
tput cup 19 3
echo "                                                                              "
rodape_dir
fi

}

#--------------------------------------

rodape_file()
{

SISTEMA="$MES $ano"
tput cup 15 3
ECHO "[ $OPER ] [ `tput smso`  $SISTEMA  `tput rmso` ] -->  Qual DIA deseja Verificar ? : \c"
read file

if [ -z "$file" ]
then
ECHO "\n               [`tput smso` $OPER `tput rmso`] Variavel DIA Incorreta !!!  `tput rmso`"
ECHO "\n                         Tecle <RETURN> para continuar ...\c"
read stop
tput cup 17 0
echo "                                                                            "
tput cup 19 0
echo "                                                                            "
rodape_file
else
echo "" > /dev/null
fi

if [ $file = 99 ]
then
opcoes
fi

echo "file=\$var$file" > /tmp/inc$HORA

. /tmp/inc$HORA
rm /tmp/inc$HORA

if [ -z "$file" ]
then
ECHO "\n               [`tput smso` $OPER `tput rmso`] Variavel DIA Incorreta !!!  `tput rmso`"
ECHO "\n                         Tecle <RETURN> para continuar ...\c"
read stop
tput cup 17 0
echo "                                                                            "
tput cup 19 0
echo "                                                                            "
rodape_file
else
echo "" > /dev/null
fi

if [ "$file" = "1" ]
then
ECHO "\n               [`tput smso` $OPER `tput rmso`] Variavel DIA Sem conteudo !!!  `tput rmso`"
ECHO "\n                         Tecle <RETURN> para continuar ...\c"
read stop
rodape_file
else
echo "" > /dev/null
fi

if [ -f $sistema/$file ]
then
ECHO "\n               [`tput smso` $OPER `tput rmso`] DIA $dia Nao Existe !!!  `tput rmso`"
ECHO "\n                         Tecle <RETURN> para continuar ...\c"
read stop
rodape_file
else
echo "" > /dev/null
fi

}

#-----------------------------------------------------------------------------

DIR()
{
COLUNAS=3
TAMANHO=15
TIPO=dr
listar
rodape_dir

if [ $TIPO = txt ]
then
conta=`find $sistema.txt | wc -l`
else
conta=`find $sistema | wc -l`
fi

if [ "$conta" -gt 1 ]
then
echo "" > /dev/null 
else
ECHO "\n  [ $OPER ] MES $sistema sem conteudo !!!   -   Tecle <RETURN> para continuar ...\c"
read stop
menu
fi

}

#--------------------------------------

DIR_FILE()
{

cd $sistema

COLUNAS=3
TAMANHO=15
TIPO=txt
listar
rodape_file

}

#--------------------------------------

menu()
{

DIR
DIR_FILE

}

#--------------------------------------

menu

tput clear
less $file
parada

}

#-----------------------------------------------------------------------------

espera_1()
{
tput cup 22 35
echo "Aguarde 10"
tput cup 22 43
echo "09"
tput cup 22 43
sleep 1
tput cup 22 43
echo "08"
tput cup 22 43
sleep 1
tput cup 22 43
echo "07"
tput cup 22 43
sleep 1
tput cup 22 43
echo "06"
tput cup 22 43
sleep 1
tput cup 22 43
echo "05"
tput cup 22 43
sleep 1
tput cup 22 43
echo "04"
tput cup 22 43
sleep 1
tput cup 22 43
echo "03"
tput cup 22 43
sleep 1
tput cup 22 43
echo "02"
tput cup 22 43
sleep 1
tput cup 22 43
echo "01"
tput cup 22 43
sleep 5
}

#-----------------------------------------------------------------------------

ver_eventos()
{
cabecalho_1

DTATUAL="`date +%d%m%Y`"
num_eventos="`cat $FILE_EVENT | grep $DTATUAL | wc -l`"
num_eventos="`echo $num_eventos`"

if [ "$num_eventos" = 0 ]
then
tput cup 10 22
echo "Nao Ha Eventos para Hoje !!!   $DT_ATUAL"
fi

linha=4
evento=0
EVENTO=0

cat $FILE_EVENT | grep $DTATUAL | while read x
do
evento="`expr $evento + 1`"

cp2="`echo $x | cut -d\; -f2,2`"
cp3="`echo $x | cut -d\; -f3,3`"
cp4="`echo $x | cut -d\; -f4,4`"
cp5="`echo $x | cut -d\; -f5,5`"

tput cup $linha 3
echo "Cadastrado Por : $cp3     Cadastrado em : $cp4"
linha="`expr $linha + 1`"
tput cup $linha 3
echo "($cp5) : $cp2"
linha="`expr $linha + 2`"

if [ "$evento" = 6 ]
then
linha=4
evento=0
espera_1
cabecalho_1
fi

done
}

#-----------------------------------------------------------------------------

ver_tabela_eventos()
{
cabecalho_1

linha=4
evento=0

cat $FILE_EVENT | while read x
do
evento="`expr $evento + 1`"

cp1="`echo $x | cut -d\; -f1,1`"
cp2="`echo $x | cut -d\; -f2,2`"
cp3="`echo $x | cut -d\; -f3,3|awk '{print $1}'`"
cp4="`echo $x | cut -d\; -f4,4`"
cp5="`echo $x | cut -d\; -f5,5`"

dia="`echo $cp1|cut -c1-2`"
mes="`echo $cp1|cut -c3-4`"
ano="`echo $cp1|cut -c5-8`"

DT_ev="$dia/$mes/$ano"

tput cup $linha 3
echo "Cadastrado Por : $cp3  Cadastrado em : $cp4  Data Evento: $DT_ev"
linha="`expr $linha + 1`"
tput cup $linha 3
echo "($cp5) : $cp2"
linha="`expr $linha + 2`"

if [ "$evento" = 6 ]
then
linha=4
evento=0
espera_1
cabecalho_1
fi

done
}

#-----------------------------------------------------------------------------


opcoes()

{

tput clear

DT_ATUAL=`date +%d/%m/%Y`

cat << EOT

  $Start $HOST $Stop IP: $Start $IP $Stop Dev: $Start $TTY $Stop Data: $Start $DT_ATUAL $Stop Hora: $Start `date +%H:%M:%S` $Stop
+---------------+-------------------------------------------------------------+
| $Start             $Stop | $Start                                                           $Stop |
| $Start$LOGO_2$Stop | $Start $MENU_NAME $Stop |
| $Start             $Stop | $Start                                                           $Stop |
+---------------+-------------------------------------------------------------+
|                                                                             |
|    [`tput smso` A `tput rmso`]  -  Relatar Passagem de Turno                                      |
|    [`tput smso` B `tput rmso`]  -  Passagem de Turno de Outros Dias                               |
|    [`tput smso` C `tput rmso`]  -  Verificar Passagem de Turno Atual [ $Start  $DT_ATUAL  $Stop ]           |
|    [`tput smso` D `tput rmso`]  -  Eventos do Dia :                  [ $Start  $DT_ATUAL  $Stop ]           |
|    [`tput smso` E `tput rmso`]  -  Verificacao Tabela de Eventos (Geral)                          |
|                                                                             |
|    [`tput smso` X `tput rmso`]  -  TELA ANTERIOR                                                  |
|                                                                             |
+-----------------------------------------------------------------------------+

EOT

confirma_opcoes()
{
tput cup 19 0 
ECHO "  `tput smso` $OPER_FULL `tput rmso` Digite a Opcao :  \b\c"

read opt

 case $opt in

 A|a) passagem
      rm $PASSAGEM_FILE.uso
      opcoes ;;

 B|b) passagem_dia
      opcoes ;;

 C|c) tput clear
      less $PASSAGEM_FILE
      parada
      opcoes ;;

 D|d) tput clear
      ver_eventos
      parada
      opcoes ;;

 E|e) tput clear
      ver_tabela_eventos
      parada
      opcoes ;;

X|x) tput clear
     exit ;;

Z|z) tput clear
     exit ;;

 *) tput cup 19 0
    ECHO "        [ $OPER ] Opcao Invalida - Tecle <ENTER> para continuar ...\c"
    read stop
    tput cup 19 0
    echo "                                                                         "
    confirma_opcoes ;;

 esac
}

confirma_opcoes

}

#-----------------------------------------------------------------------------

check_sys_menu()
{

if [ -f $CRC ]
then
echo "" > /dev/null
else
ECHO "\n  Arquivo de Backup do Menu: $CRC "
ECHO "\n  NAO Existe !!"
ECHO "\n  $Start                   Contate o Administrador do Sistema !!                   $Stop"
parada
exit
fi

CK_SUM_FILE1=`cksum $CRC | awk '{print $1}'`
CK_SUM_FILE2=`cksum $OPER_PATH/$MENU.sh | awk '{print $1}'`

if [ $CK_SUM_FILE1 = $CK_SUM_FILE2 ]
then
echo "" > /dev/null
else
ECHO "\n  Script: $MENU.sh Foi alterado do Original !! "
ECHO "\n\n  $Start                   Contate o Administrador do Sistema !!                   $Stop"
parada
exit
fi

}

#-----------------------------------------------------------------------------

check_sys_menu

opcoes

