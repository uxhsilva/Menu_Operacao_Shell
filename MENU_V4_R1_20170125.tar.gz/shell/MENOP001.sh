#
# Script: MENOP001.sh ( Menu para Start de Jobs & Processos )
# Feito : Hertz S. (02/04/2000)
# Obs   : Revisao feita em 15/12/2005
#

tput clear

           MENU="MENOP001"
      OPER_NAME="OPERNAMEOPER"
     OPER_ALLOW="OPERNAMEOPER"

   cat /etc/passwd | grep ${OPER_ALLOW} | while read linha
   do
      USR="`echo ${linha} | cut -d\: -f1,1`"
      if [ "${USR}" = "${OPER_ALLOW}" ]
      then
         echo ${linha} > /tmp/oper.$$
      fi
   done

   if [ -f /tmp/oper.$$ ]
   then
      echo "${OPER_ALLOW} Existe" > /dev/null
      OHOME="`cat /tmp/oper.$$ | cut -d\: -f 6,6`"
      echo "${OHOME}" > /tmp/home.$$
      OPER_HOME="`cat /tmp/home.$$`"
      INCLUDE_DEFAULT="${OPER_HOME}/shell/.default_menu.inc"
              INCLUDE="${OPER_HOME}/shell/MENOP001.inc"
      rm /tmp/oper.$$
      rm /tmp/home.$$
   fi

cd ${OPER_HOME}/shell

if [ -f ${INCLUDE_DEFAULT} ]
then
   . ${INCLUDE_DEFAULT}
else
   echo ""
   echo "Arquivo : ${INCLUDE_DEFAULT} nao existe !!!"
   echo ""
   sleep 10
   exit 23
fi

if [ -f ${INCLUDE} ]
then
   . ${INCLUDE}
else
   echo ""
   echo "Arquivo : ${INCLUDE} nao existe !!!"
   echo ""
   sleep 10
   exit 23
fi

HORA
ct=0

conf_logname
check_sys_menu
conf_operador
